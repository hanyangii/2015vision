2013011673 Jeong Yunhee

If you want to start this program, please type next line
python main.py

If your data's dimension is 2 and number of clusters is less than 16, you can see graph of k-means and spectral 
